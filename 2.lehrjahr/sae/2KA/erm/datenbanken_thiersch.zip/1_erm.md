Übung:

![image.png](.attachments.1167125/image.png)

Gib 

 das Relationenschema aller Tabellen an:

Mother(id, name, age, address)

Child(id, name, **mother_id**)

Der Fremdschlüssel verbirgt sich implizit in der Grafik und muss ins Relationenschema!